/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package cl.duoc.veduleria;

import java.util.Scanner;

/**
 *
 * @author cetecom
 */
public class Veduleria {

    public static void main(String[] args) {
        
        int opcion;
        Scanner sc = new Scanner(System.in);
        do{
        System.out.println("Bienvenido a Verduleria");
        System.out.println("Registrar cliente");
        System.out.println("Comprar productos");
        System.out.println("Finalizar compra");
        System.out.println("Salir");
        System.out.println("Seleccione opcion:");
        opcion = sc.nextInt();
        }while(opcion != 0);
    }
}
